<?php include ("header.php"); ?>

<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->

   <nav class="navbar navbar-default navbar-fixed-top" style="background: black;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"style="font-family: cursive;">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php"style="font-family: cursive;">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="service.php"style="font-family: cursive;">Services</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="portfolio.php"style="font-family: cursive;">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php"style="font-family: cursive;">About</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="team.php"style="font-family: cursive;">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/"style="font-family: cursive;">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php"style="font-family: cursive;">Latest News</a>
                    </li>
                   <!-- <li>
                        <a class="page-scroll" href="product.php"style="font-family: cursive;">Product</a>
                    </li>--->
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog"style="font-family: cursive;">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php"style="font-family: cursive;">Careers</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php"style="font-family: cursive;">Contact</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
   
   

<div class="top_section">
        <img src="images/about-02.jpg" style=" width: 100%; height: 465px; ">
        
        <h1 style="font-family: initial;color: #fff;margin-top: -85px;font-size: 29px;padding: 10px; margin-left: 61px;"></h1>
    </div>
      



 <section id="feature" class="feature-section" style=" padding-top: 77px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-paper-plane"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Responsive Web Design</h4>
                                <p style="font-size: 16px;font-family: serif;">eDorpon software company works Multi-vendor Marketplace Websites are one of the top trending business models. We have an excellent team of experts</p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-gift"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Website Registration&Hosting </h4>
                                <p style="font-size: 16px;font-family: serif;" >POS with eCommerce helps to manage online order systematically. No more extra work, just click, create invoice & ship product to the customer's address.</p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-wordpress"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Web Development</h4>
                                <p style="font-size: 16px;font-family: serif;">A website is an online representation of your business. It can brand your organization in a short time.It represents the brand image of your company. </p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">

                        <div class="feature">
                            <i class="fa fa-pencil"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Quality Web Content writing</h4>
                                <p style="font-size: 16px;font-family: serif;">eDorpon professional works.If you are looking for the best Web Development Company & Web Content writing at an affordable budget then contact us. </p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div>
                </div><!-- /.row -->
            
            </div><!-- /.container -->
        </section>







<div id="pricing" class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <div class="section-title text-center">
                            <h3 style="
    color: #1da246;
    font-size: 29px;font-family: cursive;
">Website Design Development Pricing Package</h3>
                            <p class="white-text" style = "font-family: cursive;">The best Website Design Development company with client are helping for web design and development services for your needs.</p>
                        </div>
                    </div>
                </div>
            </div>
                    
            <div class="pricing">
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">BASIC</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>
                        
                       <!-- <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">BASIC</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                        <li>9 Normal Page</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>--->
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">PREMIUM</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>
                        
                       <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">ADVANCE</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                      
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">GOLD</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">ECONOMY</h3>
                                </div>
                                <div class="plan-price">
                                    <div class="price-value" style="font-family: cursive;font-size: 18px;">The costs depend on the features on you want<span></span></div>
                                    <div class="interval"></div>
                                </div>
                                <div class="plan-list">
                                    <ul style="font-family: cursive;font-size: 18px;">
                                        <li>Depend Storage</li>
                                        <li>Custom Design&Easy to use</li>
                                        <li>.com/.net/.org Domains</li>
                                        <li>20 Projects</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php"  class="btn-system btn-small">Contact Us</a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                        
                        
            </div>
        </div>
    </div>
    


<footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12" style="margin-left: -11px;">
                        <div class="footer-link">
                            <ul class="pull-right" style="margin-top: 1px;">
                                <li><a href="#">Privacy Policy</a><a href="#">    Terms of Use</a>
                                </li>
                                <!--<li><a href="#">Terms of Use</a>
                                </li>--->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="https://twitter.com/edorpon"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/edorponbd/"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/edorponofficial/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="www.edorpon.com"><i class="fa fa-dribbble"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </footer>
    




    <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.fitvids.js"></script>
    <script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>




