<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>eDorpon</title>



<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">






    <!-- Bootstrap Core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Animate CSS -->
    <link href="css/animate.css" rel="stylesheet" >
    
    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" >
    <link rel="stylesheet" href="css/owl.theme.css" >
    <link rel="stylesheet" href="css/owl.transitions.css" >

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css">
    
    
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css" title="green">
    <link rel="stylesheet" type="text/css" href="css/color/light-red.css" title="light-red">
    <link rel="stylesheet" type="text/css" href="css/color/blue.css" title="blue">
    <link rel="stylesheet" type="text/css" href="css/color/light-blue.css" title="light-blue">
    <link rel="stylesheet" type="text/css" href="css/color/yellow.css" title="yellow">
    <link rel="stylesheet" type="text/css" href="css/color/light-green.css" title="light-green">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    
    
    <!-- Modernizer js -->
    <script src="js/modernizr.custom.js"></script>

    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container1">
          <div class="row1">
                    <div class="col-12">
                        <nav class="navbar navbar-expand-lg navbar-light bg-light">
     <a class="navbar-brand" href="#">eDrpon</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>

  <div class="collapse navbar-collapse" id="navbar">
    <ul class="navbar-nav ml-auto" style="   margin: 10px;font-size:16px; float: right;">
      <!---HOME PROTFOLIO ABOUT SEVICES TEAM SHOP LATEST NEWS BLOG CAREER -->
      <li class="nav-item">
        <a class="nav-link" href="#" class="dropdown-toggle">Home</a>
      </li>
      

      

      <li class="nav-item dropdown menu-area">
        <a class="nav-link dropdown-toggle" href="#" id="mega-one"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Services          
        </a>
        <div class="dropdown-menu mega-area" aria-labelledby="mega-one">

         <div class="row">
            <div class="col-sm-6 col-lg-4" style="background: rgb(17, 198, 19) none repeat scroll 0% 0%; color: rgb(0, 0, 0); margin: 15px;padding: 64px;margin-top: -5px;margin-right: 0px;margin-left: -116px;margin-inline-end: 50px;margin-block-end: -6px;">
                
                <h4 style="font-family: auto; line-height: 24px; color: #e8e8ee; width:748px;font-size: 15px;padding-top: 4px;margin-top: -41px;margin-right: 7px;margin-left: -54px;/*! padding-top: 6px;">

      <li ><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-graduation-cap" style="color: #ffff;"></i>School Management</a></li>

      <li ><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-shopping-bag" style="color: #ffff;"></i>Web Design</a></li>
                

      <li><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-briefcase" style="color: #ffff;"></i>Business Management</a></li>

       <li><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-btc" ></i>Mobile Application</a></li>

      <li><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-stethoscope"></i>e-Commerce Solution</a></li>

      <li><a href="#" data-toggle="tab"style="color: #ffff;"><i class="fa fa-handshake-o"></i>Branding</a></li>
    
      <li><a href="#" data-toggle="tab" style="color: #ffff;"><i class="fa fa-newspaper-o"></i>Travel,Tour,Visa Process</a></li>


            </h4>
            </div>

                <div class="col-sm-6 col-lg-7">
                <h5>Graphics Design</h5>
                <a href="#" data-toggle="tab"><i class="fa fa-graduation-cap"></i>School Management</a></br>
                <a href="#" data-toggle="tab"><i class="fa fa-newspaper-o"></i>Travel,Tour,Visa Process</a></br>
                <a href="#" data-toggle="tab"><i class="fa fa-briefcase"></i>Business Management</a></br>
                <a href="#" data-toggle="tab"><i class="fa fa-briefcase"></i>Business Management</a></br>
                <a href="#" data-toggle="tab"><i class="fa fa-briefcase"></i>Business Management</a></br>
                <a href="#" data-toggle="tab"><i class="fa fa-briefcase"></i>Business Management</a></br>
                </div>

               <!-- <div class="col-sm-6 col-lg-2">
                <h5>Company Profile</h5>
                <p>We are reputed multi-national company</p>
                </div> --->
               
         </div>


        </div>
      </li>

      </li> 
       <li class="nav-item">
        <a class="nav-link" href="#">PROTFOLIO</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#">ABOUT</a>
    </li>
      <li class="nav-item">
        <a class="nav-link" href="#">SHOP</a>
      </li> 
      
      <li class="nav-item">
        <a class="nav-link" href="#">LATEST NEWS</a>
      </li> 
       <li class="nav-item">
        <a class="nav-link" href="#">CAREER</a>
      </li> 

      
    </ul>
    
  </div>
</nav>
                    </div>
                    
                </div>
            </div>
        <!-- /.container-fluid -->
    </nav>


     
    
    
    
    <!-- Start Home Page Slider -->
    <div class="top_section">
        <img src="images/portfolio/img4.jpg" style=" width: 100%; height: 514px; ">
        <h1 style="font-family: initial;color: #0d6510;margin-left: 444px;margin-top: -85px;font-size: 28px;">Business Management Software</h1>
    </div>

    <!-- End Home Page Slider -->

    
    
    <!-- Start Feature Section -->
     
        <!-- End Feature Section -->
    
    
    <!-- Start Call to Action Section -->
    <section class="call-to-action">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>"eDorpon is an international standard Software Company in Bangladesh since 2018. We aim to provide fully interactive and cost-effective solutions by establishing a bridge between the latest Smart Technologies"</h1>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- End Call to Action Section -->
    
    
    
    <!-- Start Portfolio Section -->
       
        <!-- End Portfolio Section -->
    
    <!-- Start Portfolio Modal Section -->
       
        <!-- End Portfolio Modal Section -->
    
    
    <!-- Start About Us Section -->

   
    <!-- End About Us Section -->


    <!-- Start About Us Section 2 -->
 
    <!-- Start About Us Section 2 -->


    


    <!-- Start Feature Section -->
       
        <!-- End Feature Section -->
    
    
    
    <!-- Start Fun Facts Section -->
    
    <!-- End Fun Facts Section -->



    <!-- Start Team Member Section -->
    
    <!-- End Team Member Section -->



    <!-- Start Pricing Table Section -->
    
    <!-- End Pricing Table Section -->
    
    
    
    <!-- Start Latest News Section -->
    
    <!-- End Latest News Section -->



    
    
    
    <!-- Start Testimonial Section -->
    
    

    <!-- Clients Aside -->
    
    
    
    

   <section id="contact1" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <h3 >Contact With Us</h3>
                        <p  >Meet our experts best solution for you </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-contact-info">
                        <h4 >Contact info</h4>
                        <ul>
                            <li><strong>E-mail :</strong> edorpon@gmail.com</li>
                            <li><strong>Phone :</strong> +8801730-716580</li>
                            <li><strong>Mobile :</strong> +8801888-015003</li>
                            <li><strong>Web :</strong> www.edorpon.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-4">
                    <div class="footer-contact-info">
                        <h4 >Working Hours</h4>
                        <ul>
                            <li><strong>Mon-Wed :</strong> 10 am to 6 pm</li>
                            <li><strong>Sunday :</strong> 10 pm to 6 pm</li>
                            <li><strong>Sat :</strong> 10 am to 6 pm</li>
                            <li><strong>Thurs-Fri :</strong> Closed</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
         <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-link">
                            <ul class="pull-right">
                                <li><a href="#">Privacy Policy</a>
                                </li>
                                <li><a href="#">Terms of Use</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </section>
    
   <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.fitvids.js"></script>
    <script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>


